import { Component, EventEmitter, Input, OnInit, Output, } from "@angular/core";
import { newEmployeeData, newSignupDetails } from "../types";
import { EmployeeDetailsService } from "../app.service";
import { Router } from "@angular/router";
import { FormControl, FormGroup, Validators } from "@angular/forms";

@Component({
    selector: 'app-sign-up',
    templateUrl: './sign-up.component.html',
    styleUrls: ['./sign-up.component.css']
})

export class SignUpComponent {

    showPassword: boolean = false;
    showConfirmPassword: boolean = false;
    @Output() newSignUpData = new EventEmitter<newEmployeeData>();
    @Output() loginDetails = new EventEmitter<{ empUserName: string, empPassword: string, empConfirmPassword: string }>();
    @Input() isExist: any;

    constructor(private allEmployeeDetails: EmployeeDetailsService, private route: Router) { }

    userForm = new FormGroup({
        empUserName: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z0-9](?:[a-zA-Z0-9._]){2,18}[a-zA-Z0-9]$/)]),
        empPassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/)]),
        empConfirmPassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/)]),
        role: new FormControl('superAdmin', Validators.required)
    })

    signUp() {
        const formData: newSignupDetails = this.userForm.value as newSignupDetails;

        if (formData && this.userForm.valid) {
            this.getEmployee(formData);
            this.userForm.reset();
        }
    }

    signIn() {
        this.route.navigate(['/login'])
    }

    getEmployee(data: newSignupDetails) {

        if (data.empPassword !== data.empConfirmPassword) {
            return alert('Password and Confirm Password not match');
        }
        else if (this.allEmployeeDetails.userDetails.find(item => item.empUserName === data.empUserName)) {
            return alert("User Already Exists")
        }
        else {
            this.allEmployeeDetails.userDetails.push(data);

            this.route.navigate(['/login'])
        }
    }

    onShow() {
        this.showPassword = true;
    }

    onHide() {
        this.showPassword = false;
    }

    onShowConfirmPassword() {
        this.showConfirmPassword = true;
    }

    onHideConfirmPassword() {
        this.showConfirmPassword = false;
    }
}