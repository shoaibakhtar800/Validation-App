import { Injectable } from "@angular/core";
import { CompanyEmployeeType, companyEmployeeType } from "./types";

@Injectable({
    providedIn: 'root',
})

export class EmployeeDetailsService {

    canActivateFlag: boolean = false;
    currentDataValidate: any = {};
    employeeNameAndAddress: any = {};
    uniqueEmployeeId: number | undefined;
    employeeName: string = "";
    employeeAddress: string = "";
    currentEmployeeDetails: CompanyEmployeeType | null = null;

    constructor() {

    }

    userDetails: companyEmployeeType[] = [
        {
            empUserName: "shoaib_123",
            empPassword: "Shoaib@123",
            role: 'superAdmin'
        },
        {
            empUserName: "rony_987",
            empPassword: "Rony@856",
            role: 'admin'
        },
        {
            empUserName: "sam_645",
            empPassword: "Sam@891",
            role: 'superAdmin'
        },
        {
            empUserName: "tom_963",
            empPassword: "Tom@741",
            role: 'admin'
        },
        {
            empUserName: "emp_CharlieBrown",
            empPassword: "Password@345",
            role: 'superAdmin'
        },
        {
            empUserName: "emp_SnoopyDog",
            empPassword: "Password@678",
            role: 'admin'
        },
        {
            empUserName: "emp_LucyVanPelt",
            empPassword: "Password@901",
            role: 'admin'
        },
        {
            empUserName: "emp_LinusVanPelt",
            empPassword: "Password@234",
            role: 'superAdmin'
        },
        {
            empUserName: "linux_123",
            empPassword: "Kali@1234",
            role: 'admin'
        }
    ]

    employeeDetailsList: CompanyEmployeeType[] = [
        {
            empId: 1,
            empName: "shoaib akhtar",
            empCurrentAddress: "subhash nagar",
            empPermanentAddress: "parul university",
            empCountry: "india",
            empContactNumber: 123456789,
        },
        {
            empId: 2,
            empName: "prateek",
            empCurrentAddress: "bihar",
            empPermanentAddress: "parul university",
            empCountry: "india",
            empContactNumber: 165456789,
        },
        {
            empId: 3,
            empName: "faizan",
            empCurrentAddress: "hyderabad",
            empPermanentAddress: "parul university",
            empCountry: "india",
            empContactNumber: 6875215455,
        },
        {
            empId: 4,
            empName: "amod",
            empCurrentAddress: "bihar",
            empPermanentAddress: "parul university",
            empCountry: "india",
            empContactNumber: 8458461645,
        },
        {
            empId: 5,
            empName: "krutik",
            empCurrentAddress: "ahmedabad",
            empPermanentAddress: "parul university",
            empCountry: "india",
            empContactNumber: 952641526,
        },
        {
            empId: 6,
            empName: "sam",
            empCurrentAddress: "haryana",
            empPermanentAddress: "parul university",
            empCountry: "india",
            empContactNumber: 956551526,
        }
    ]

    isArrayisEmptyOrNot() {
        return this.userDetails.length > 0;
    }

    fetchEmployeeDataById() {
        this.employeeDetailsList.find(item => {

            if (item.empId === this.uniqueEmployeeId) {
                this.currentEmployeeDetails = item;
            }

        })
    }

    async dataFetch() {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts');

        const data = await response.json();

        return data;
    }

}