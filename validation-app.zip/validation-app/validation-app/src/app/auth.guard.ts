import { inject } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivateFn, CanDeactivateFn, RouterStateSnapshot } from "@angular/router";
import { EmployeeDetailsService } from "./app.service";

export const canActivateFn : CanActivateFn = (route: ActivatedRouteSnapshot, state: RouterStateSnapshot) => {
    const authServiceData = inject(EmployeeDetailsService);
    return authServiceData.canActivateFlag ? true : false;
}
