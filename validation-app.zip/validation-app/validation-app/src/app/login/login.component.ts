import { Component, EventEmitter, Input, Output } from "@angular/core";
import { newEmployeeData, userLoginDetails } from "../types";
import { EmployeeDetailsService } from "../app.service";
import { Router } from "@angular/router";
import { FormControl, FormGroup, Validators } from "@angular/forms";

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})

export class LoginComponent {
    showPassword: boolean = false;

    @Input() flag: boolean = false;
    @Input() newEmpDetail!: newEmployeeData;
    @Output() isOpenSignUp = new EventEmitter<boolean>();

    constructor(private allEmployeeDetails: EmployeeDetailsService, private route: Router) { }

    loginForm = new FormGroup({
        empUserName: new FormControl('', [Validators.required, Validators.pattern(/^[a-zA-Z0-9](?:[a-zA-Z0-9._]){2,18}[a-zA-Z0-9]$/)]),
        empPassword: new FormControl('', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*])[A-Za-z\d!@#$%^&*]{8,}$/)])
    })

    onLogin() {
        const loginDetailForm : userLoginDetails = this.loginForm.value as userLoginDetails;

        if(loginDetailForm && this.loginForm.valid) {
            this.getEmployee(loginDetailForm);
            this.loginForm.reset();
        }
    }

    onSignUp() {
        this.route.navigate(['/signup'])
    }

    getEmployee(data: userLoginDetails) {
        console.log(data);

        let flag = this.allEmployeeDetails.isArrayisEmptyOrNot();

        if (!flag) {
            return alert('No employee available');
        }

        this.allEmployeeDetails.userDetails.find((item) => {
            if (item.empUserName === data.empUserName && item.empPassword === data.empPassword) {
                this.flag = true;

                this.allEmployeeDetails.currentDataValidate = item;

                this.allEmployeeDetails.canActivateFlag = true;

                this.route.navigate(['/company'])
            }
        })

        if (!this.flag) alert('User not found');
    }

    onShow() {
        this.showPassword = true;
    }

    onHide() {
        this.showPassword = false;
    }

}