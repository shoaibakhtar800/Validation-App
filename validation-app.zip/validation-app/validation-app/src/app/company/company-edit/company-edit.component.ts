import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeDetailsService } from 'src/app/app.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { CanComponentDeactivate } from 'src/app/can-deactivate-guard.service';

@Component({
    selector: 'company-edit',
    templateUrl: 'company-edit.component.html',
    styleUrls: ['./company-edit.component.css']
})

export class CompanyEditComponent implements OnInit, CanComponentDeactivate {

    editEmployeeName: string = "";
    editEmployeeAddress: string = "";
    goBackWithoutPopup: boolean = true;

    constructor(private editSectionToggle: EmployeeDetailsService, private route: Router, private activatedRoute: ActivatedRoute) { }

    companyEdit = new FormGroup({
        empName: new FormControl('', Validators.required),
        empCurrentAddress: new FormControl('', Validators.required),
        empPermanentAddress: new FormControl('', Validators.required),
        empCountry: new FormControl('', Validators.required)
    })

    ngOnInit() {
        this.activatedRoute.params.subscribe(params => {
            this.editSectionToggle.uniqueEmployeeId = Number(params['id']);
        })

        this.editSectionToggle.fetchEmployeeDataById();

        if (this.editSectionToggle.currentEmployeeDetails) {
            this.companyEdit.patchValue(this.editSectionToggle.currentEmployeeDetails)
        }

    }

    onSubmit() {
        const empNameValue = this.companyEdit.controls.empName.value;
        const empCurrentValue = this.companyEdit.controls.empCurrentAddress.value;
        const empPermanentValue = this.companyEdit.controls.empPermanentAddress.value
        const empCountry = this.companyEdit.controls.empCountry.value;
        
        if (empNameValue && empCurrentValue && empPermanentValue && empCountry) {
            this.editSectionToggle.currentEmployeeDetails!.empName = empNameValue
            this.editSectionToggle.currentEmployeeDetails!.empCurrentAddress = empCurrentValue;
            this.editSectionToggle.currentEmployeeDetails!.empPermanentAddress = empPermanentValue;
            this.editSectionToggle.currentEmployeeDetails!.empCountry = empCountry

            this.goBackWithoutPopup = false;
            this.route.navigate(['/company'])
        }
        else {
            alert('Please enter full details')
        }
    }

    onCancel() {
        this.goBackWithoutPopup = false;
        this.route.navigate(['/company'])
    }

    canDeactivate(): boolean | Observable<boolean> | Promise<boolean> {
        if (this.goBackWithoutPopup) {
            return confirm('Do you really want to go back🔙');
        }
        else {
            return true;
        }
    }
}