import { NgModule } from '@angular/core';
import { CompanyComponent } from './company.component';
import { CompanyEditComponent } from './company-edit/company-edit.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FontSizeModule } from '../shared/directive.module';
import { CompanyRoutingModule } from './company-routing.module';
import { CanDeactivateGuard } from '../can-deactivate-guard.service';

@NgModule({
    imports: [
        FormsModule,
        CommonModule,
        FontSizeModule,
        CompanyRoutingModule,
        ReactiveFormsModule
    ],
    exports: [],
    declarations: [
        CompanyComponent,
        CompanyEditComponent
    ],
    providers: [CanDeactivateGuard],
})
export class CompanyModule { }
