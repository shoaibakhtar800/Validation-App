import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { CompanyComponent } from "./company.component";
import { CompanyEditComponent } from "./company-edit/company-edit.component";
import { NotFoundComponent } from "../notfound/notfound.component";
import { CanDeactivateGuard } from "../can-deactivate-guard.service";

const routes: Routes = [
    { path: '', component: CompanyComponent },
    { path: 'edit-company/:id', component: CompanyEditComponent, canDeactivate: [CanDeactivateGuard]},
    { path: '**', component: NotFoundComponent }
]

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})

export class CompanyRoutingModule {}