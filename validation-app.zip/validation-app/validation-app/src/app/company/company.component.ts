import { Component, OnInit } from "@angular/core";
import { EmployeeDetailsService } from "../app.service";
import { CompanyEmployeeType } from "../types";
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";

@Component({
    selector: 'app-company',
    templateUrl: './company.component.html',
    styleUrls: ['./company.component.css']
})

export class CompanyComponent implements OnInit {

    editEmployeeDetails : any = {}
    employeeDetailsList : CompanyEmployeeType[] = [] 
    nameSearchValue : string = "";
    searchVal : string = "";

    constructor(public editSectionToggle : EmployeeDetailsService, private route: Router, private activeRoute: ActivatedRoute) { 
        this.route.events.subscribe((event) => {
            if(event instanceof NavigationEnd) {
                if(event.id === 1 && event.url === event.urlAfterRedirects) {
                    this.route.navigate(['/login'])
                }
            }
        })
    }

    ngOnInit() : void {
        this.employeeDetailsList = this.editSectionToggle.employeeDetailsList;
    }

    changeDetails(event : any) { 
        this.route.navigate(['edit-company', event.empId], { relativeTo: this.activeRoute })
    }   

    onEmployeeName(data : string) {
        this.editEmployeeDetails.empName = data;
    }

    onEmployeeAddress(data : string) {
        this.editEmployeeDetails.empAddress = data;
    }

    onChangeSearch(event : any) {
        this.nameSearchValue = event.target.value;
        event.target.value = "";
    }

    onLogout() {
        const isLoginOrLogout = confirm('Do you really want to logout❓')
        isLoginOrLogout && this.route.navigate(['/login'])
    }
}