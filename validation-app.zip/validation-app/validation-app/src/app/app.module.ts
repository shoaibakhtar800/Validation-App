import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SignUpComponent } from './sign-up/sign-up.component';
import { CommonModule } from '@angular/common';
import { FontSizeModule } from './shared/directive.module';
import { EmployeeDetailsService } from './app.service';
import { AppRoutingModule } from './app-routing.module';
import { NotFoundComponent } from './notfound/notfound.component';
import { RulesComponent } from './rules/rules.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignUpComponent,
    NotFoundComponent,
    RulesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    CommonModule,
    FontSizeModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [EmployeeDetailsService],
  bootstrap: [AppComponent]
})
export class AppModule { }
