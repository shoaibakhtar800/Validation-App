import { Component } from "@angular/core";

@Component({
    selector: 'app-rules',
    templateUrl: 'rules.component.html'
})

export class RulesComponent {

    constructor() {}

}