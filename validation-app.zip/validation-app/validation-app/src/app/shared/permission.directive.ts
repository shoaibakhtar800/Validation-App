import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';
import { permissionDetailsType } from '../types';
import { EmployeeDetailsService } from '../app.service';

@Directive({ selector: '[permission]' })

export class PermissionDirective {
    constructor(private viewContainerRef: ViewContainerRef, private templateRef: TemplateRef<string>, private employeeServices: EmployeeDetailsService) { }

    permissionDetails: permissionDetailsType[] = [
        {
            role: 'superAdmin',
            permissions: ["view", "edit"]
        },
        {
            role: 'admin',
            permissions: ["view"]
        }
    ]

    // permissions : string[] = ['admin', 'superAdmin'];

    @Input() set permission(userRole: string) {

        this.permissionDetails.find(detail => {
            if (detail.role === this.employeeServices.currentDataValidate.role) {
                if (detail.permissions.includes(userRole)) {
                    this.viewContainerRef.createEmbeddedView(this.templateRef)
                }
                else {
                    this.viewContainerRef.clear();
                }
            }

        })
    }
}