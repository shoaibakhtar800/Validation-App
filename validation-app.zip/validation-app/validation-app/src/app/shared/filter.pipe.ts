import { Pipe, PipeTransform } from '@angular/core';
import { CompanyEmployeeType } from '../types';

@Pipe({
    name: 'filterName'
})

export class FilterPipe implements PipeTransform {
    transform(value: CompanyEmployeeType[], key: string, val: string): any {

        if (!value || !val) {
            return value;
        }

        const lowerCaseFilter = val.toLowerCase();

        return value.filter((item : any) => {
            return item[key].toLowerCase().includes(lowerCaseFilter);
        });

    }
}