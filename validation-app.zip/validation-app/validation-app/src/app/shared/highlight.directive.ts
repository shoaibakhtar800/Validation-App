import { Directive, ElementRef, HostBinding, HostListener } from '@angular/core';

@Directive({ selector: '[highLight]' })

export class highLightDirective {
    @HostBinding('style.backgroundColor') backgroundColor : string = 'transparent';
    @HostBinding('style.color') Color : string = 'black';

    constructor(private el : ElementRef) { }

    @HostListener('mouseenter') mouseEnter(eventData : Event) {
        this.backgroundColor = '#c3a1e6';
        this.Color = 'white'
    } 

    @HostListener('mouseleave') mouseLeave(eventData: Event) {
        this.backgroundColor = 'transparent';
        this.Color = 'black'
    }
}