import { NgModule } from '@angular/core';
import { FontSizeDirective } from './font-size.directive';
import { highLightDirective } from './highlight.directive';
import { PermissionDirective } from './permission.directive';
import { titleCasePipe } from './titlecase.pipe';
import { FilterPipe } from './filter.pipe';

@NgModule({
    declarations: [FontSizeDirective, highLightDirective, PermissionDirective, titleCasePipe, FilterPipe],
    imports: [],
    exports: [FontSizeDirective, highLightDirective, PermissionDirective, titleCasePipe, FilterPipe],
    providers: [],
})

export class FontSizeModule { }