import { Directive, ElementRef, Input, OnInit } from "@angular/core";

@Directive({
    selector: '[FontSize]'
})

export class FontSizeDirective implements OnInit {

    @Input() FontSize : string = '';

    constructor(private el : ElementRef) {
    }

    ngOnInit(): void {
        this.el.nativeElement.style.fontSize = this.FontSize;
    }

}