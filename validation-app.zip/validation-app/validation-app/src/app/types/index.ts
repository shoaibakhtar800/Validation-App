export interface newEmployeeData {
    empUserName : string;
    empPassword : string;
    empConfirmPassword : string;
}

export interface companyEmployeeType {
    empUserName: string;
    empPassword: string;
    role?: string;
}

export interface CompanyEmployeeType {
    empId : number;
    empName : string;
    empCurrentAddress : string;
    empPermanentAddress : string;
    empCountry: string;
    empContactNumber : number;
}

export interface employeeNameAndAddress {
    empName : string;
    empAddress : string;
}

export interface permissionDetailsType {
    role: string;
    permissions: string[];
}

export interface newSignupDetails {
    empUserName: string;
    empPassword: string;
    empConfirmPassword: string;
    role: string;
}

export interface userLoginDetails {
    empUserName : string;
    empPassword : string;
}