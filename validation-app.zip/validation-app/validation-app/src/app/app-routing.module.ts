import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { SignUpComponent } from "./sign-up/sign-up.component";
import { LoginComponent } from "./login/login.component";;
import { NotFoundComponent } from "./notfound/notfound.component";
import { canActivateFn } from "./auth.guard";

const routes: Routes = [
    { path: '', redirectTo: '/signup', pathMatch: "full" },
    { path: 'signup', component: SignUpComponent },
    { path: 'login', component: LoginComponent },
    // { path: 'company', component: CompanyComponent },
    { path: 'company', loadChildren: () => import('src/app/company/company.module').then(x => x.CompanyModule), canActivate: [canActivateFn] },
    { path: '**', component: NotFoundComponent }
]

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule {}