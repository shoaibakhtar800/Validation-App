import { Component } from '@angular/core';
import { newEmployeeData } from './types';
import { EmployeeDetailsService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent {
  allEmployeeData: any;
  newLoginDetails: any;
  newEmployeeDetail!: newEmployeeData;
  data: any;

  constructor(private dataFetch: EmployeeDetailsService) { }

  newEmpData(data: newEmployeeData) {
    this.newEmployeeDetail = data;
  }

  onFetch() {
    setTimeout(() => {
      const data = this.dataFetch.dataFetch();

      data.then(data => {
        this.data = data;
      }).catch(err => {
        console.log(err);
      })
    }, 2000)
  }
}
